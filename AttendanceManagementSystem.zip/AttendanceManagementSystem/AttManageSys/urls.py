from django.urls import path, include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import (
    UserViewSet,
    DepartmentViewSet,
    CourseViewSet,
    StudentProfileViewSet,
    AttendanceRecordViewSet,
)

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'departments', DepartmentViewSet)
router.register(r'courses', CourseViewSet)
router.register(r'students', StudentProfileViewSet)
router.register(r'attendance', AttendanceRecordViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    # path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    # path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
# The above code sets up the URL routing for the Django application, including the API endpoints for user authentication and management of various entities like departments, courses, students, and attendance records. It uses Django REST Framework's router to automatically generate the necessary routes for the viewsets defined in the views.py file. The JWT authentication is also configured to handle token-based authentication for secure access to the API.