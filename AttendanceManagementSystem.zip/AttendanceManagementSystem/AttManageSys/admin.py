from django.contrib import admin
from .models import * #Users, Department, course, StudentProfile, AttendanceRecord

# Register your models here.
admin.site.register(Users)
admin.site.register(Department)
admin.site.register(course)
admin.site.register(StudentProfile)
admin.site.register(AttendanceRecord)
