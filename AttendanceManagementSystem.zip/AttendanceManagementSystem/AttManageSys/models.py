from django.db import models

# Create your models here.
class Users(models.Model):
    type_choices = [
        ('student', 'Student'),
        ('teacher', 'Teacher'),
        ('admin', 'Admin'),
    ]
    full_name = models.CharField(max_length=100)
    username = models.CharField(max_length=100, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    user_type = models.CharField(max_length=10, choices=type_choices, default='student')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.username
    
class Department(models.Model):
    department_name = models.CharField(max_length=100, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.department_name
    
class course(models.Model):
    course_name = models.CharField(max_length=100, unique=True)
    course_code = models.CharField(max_length=20, unique=True)
    department_id = models.ForeignKey(Department, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.course_name
    
class StudentProfile(models.Model):
    user = models.OneToOneField(Users, on_delete=models.CASCADE)
    roll_number = models.CharField(max_length=20, unique=True)
    department_id = models.ForeignKey(Department, on_delete=models.CASCADE)
    course_id = models.ForeignKey(course, on_delete=models.CASCADE)
    session = models.CharField(max_length=20)
    year_of_study = models.IntegerField()

    def __str__(self):
        return f"{self.user.username} - {self.roll_number}"
#design Attendance Management System backend
class AttendanceRecord(models.Model):
    student_id = models.ForeignKey(StudentProfile, on_delete=models.CASCADE)
    course_id = models.ForeignKey(course, on_delete=models.CASCADE)
    Department_id = models.ForeignKey(Department, on_delete=models.CASCADE)
    present_absent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    

    def __str__(self):
        return f"{self.student_id} - {self.course_id}"


    

    





